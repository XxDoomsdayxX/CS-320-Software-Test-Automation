package main;

import java.util.ArrayList;
import java.util.List;

public class ContactService {
	// create a list called contacts
	private List<Contact> contacts = new ArrayList<>(); 
	
	public void addContact(Contact contact) {
		for (int i = 0; i < contacts.size(); i++ ) {
			if (contacts.get(i).getContactId().equals(contact.getContactId())) {
	            throw new IllegalArgumentException("Contact ID already exists");
	        }
		}
		contacts.add(contact);
	}

	public void deleteContact(String contactId) {
	    boolean contactFound = false;
	    for (int i = 0; i < contacts.size(); i++) {
	        if (contacts.get(i).getContactId().equals(contactId)) {
	            contacts.remove(i);
	            contactFound = true;
	            break; // Exit the loop after removing the contact
	        }
	    }
	    if (!contactFound) {
	        throw new IllegalArgumentException("Contact ID not found!");
	    }
	}
	
	public void updateContact(String contactId, String firstName, String lastName, String phone, String address) {
	    boolean contactFound = false;
	    for (int i = 0; i < contacts.size(); i++) {
	        if (contacts.get(i).getContactId().equals(contactId)) {
	            if (firstName != null && !firstName.isEmpty()) {
	                contacts.get(i).setFirstName(firstName);
	            }
	            if (lastName != null && !lastName.isEmpty()) {
	                contacts.get(i).setLastName(lastName);
	            }
	            if (phone != null && !phone.isEmpty()) {
	                contacts.get(i).setPhone(phone);
	            }
	            if (address != null && !address.isEmpty()) {
	                contacts.get(i).setAddress(address);
	            }
	            contactFound = true;
	            break; // Exit the loop after updating the contact
	        }
	    }
	    if (!contactFound) {
	        throw new IllegalArgumentException("Contact ID not found!");
	    }
	}

	
	public List<Contact> getContacts() {
	    return new ArrayList<>(contacts); // Return a copy of the list
	}

}
