package test;

import main.Contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ContactTest {

    // Test Constructor with Valid Inputs
    @Test
    public void testValidContactCreation() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main Street");

        assertEquals("12345", contact.getContactId());
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main Street", contact.getAddress());
    }

    // Test Constructor with Invalid Inputs
    @Test
    public void testConstructorInvalidInputs() {
        assertThrows(IllegalArgumentException.class, () -> new Contact(null, "John", "Doe", "1234567890", "123 Main Street"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("12345678901", "John", "Doe", "1234567890", "123 Main Street")); // Too long ID
        assertThrows(IllegalArgumentException.class, () -> new Contact("12345", null, "Doe", "1234567890", "123 Main Street")); // Null first name
        assertThrows(IllegalArgumentException.class, () -> new Contact("12345", "John", "Doe", "123", "123 Main Street")); // Invalid phone
        assertThrows(IllegalArgumentException.class, () -> new Contact("12345", "John", "Doe", "1234567890", null)); // Null address
    }

    // Test Constructor with Boundary Values
    @Test
    public void testConstructorBoundaryValues() {
        Contact contact = new Contact("1234567890", "JohnJohnJo", "DoeDoeDoeD", "1234567890", "123456789012345678901234567890");
        assertEquals("1234567890", contact.getContactId());
        assertEquals("JohnJohnJo", contact.getFirstName());
        assertEquals("DoeDoeDoeD", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123456789012345678901234567890", contact.getAddress());
    }

    // Test Getters
    @Test
    public void testGetters() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main Street");
        assertEquals("12345", contact.getContactId());
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main Street", contact.getAddress());
    }

    // Test Setters with Valid Inputs
    @Test
    public void testSettersValidInputs() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main Street");

        contact.setFirstName("Jane");
        assertEquals("Jane", contact.getFirstName());

        contact.setLastName("Smith");
        assertEquals("Smith", contact.getLastName());

        contact.setPhone("0987654321");
        assertEquals("0987654321", contact.getPhone());

        contact.setAddress("456 Elm Street");
        assertEquals("456 Elm Street", contact.getAddress());
    }

    // Test Setters with Invalid Inputs
    @Test
    public void testSettersInvalidInputs() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main Street");

        // Invalid First Name
        assertThrows(IllegalArgumentException.class, () -> contact.setFirstName(null));
        assertThrows(IllegalArgumentException.class, () -> contact.setFirstName("ThisNameIsWayTooLong"));

        // Invalid Last Name
        assertThrows(IllegalArgumentException.class, () -> contact.setLastName(null));
        assertThrows(IllegalArgumentException.class, () -> contact.setLastName("ThisLastNameIsWayTooLong"));

        // Invalid Phone
        assertThrows(IllegalArgumentException.class, () -> contact.setPhone(null));
        assertThrows(IllegalArgumentException.class, () -> contact.setPhone("123")); // Too short
        assertThrows(IllegalArgumentException.class, () -> contact.setPhone("1234567890123")); // Too long
        assertThrows(IllegalArgumentException.class, () -> contact.setPhone("abcdefghij")); // Non-numeric

        // Invalid Address
        assertThrows(IllegalArgumentException.class, () -> contact.setAddress(null));
        assertThrows(IllegalArgumentException.class, () -> contact.setAddress("This address is far too long for the system to accept"));
    }

    // Test Contact ID Immutability
    @Test
    public void testContactIdIsImmutable() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main Street");
        assertEquals("12345", contact.getContactId());
    }
}
