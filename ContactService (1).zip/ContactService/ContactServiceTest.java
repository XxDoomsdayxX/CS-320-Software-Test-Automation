package test;

import main.Contact;
import main.ContactService;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ContactServiceTest {

    // Test Adding a Single Contact
    @Test
    public void testAddContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");

        service.addContact(contact);

        assertEquals(1, service.getContacts().size()); // Check if the contact was added
        assertEquals(contact, service.getContacts().get(0)); // Verify it's the correct contact
    }

    // Test Adding Multiple Contacts
    @Test
    public void testAddMultipleContacts() {
        ContactService service = new ContactService();
        Contact contact1 = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        Contact contact2 = new Contact("67890", "Jane", "Smith", "0987654321", "456 Elm St");

        service.addContact(contact1);
        service.addContact(contact2);

        assertEquals(2, service.getContacts().size()); // Check if both contacts were added
        assertEquals(contact1, service.getContacts().get(0)); // Verify first contact
        assertEquals(contact2, service.getContacts().get(1)); // Verify second contact
    }

    // Test Adding a Contact with Duplicate ID
    @Test
    public void testAddContactDuplicateId() {
        ContactService service = new ContactService();
        Contact contact1 = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        Contact contact2 = new Contact("12345", "Jane", "Smith", "0987654321", "456 Elm St");

        service.addContact(contact1);

        // Adding a second contact with the same ID should throw an exception
        assertThrows(IllegalArgumentException.class, () -> service.addContact(contact2));
    }

    // Test Deleting a Contact
    @Test
    public void testDeleteContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(contact);

        service.deleteContact("12345");

        assertEquals(0, service.getContacts().size()); // Check if the contact was deleted
    }

    // Test Deleting a Non-Existent Contact
    @Test
    public void testDeleteNonexistentContact() {
        ContactService service = new ContactService();

        // Deleting a non-existent contact should throw an exception
        assertThrows(IllegalArgumentException.class, () -> service.deleteContact("12345"));
    }

    // Test Updating All Fields of a Contact
    @Test
    public void testUpdateContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(contact);

        service.updateContact("12345", "Jane", "Smith", "0987654321", "456 Elm St");

        Contact updatedContact = service.getContacts().get(0); // Retrieve the updated contact
        assertEquals("Jane", updatedContact.getFirstName());
        assertEquals("Smith", updatedContact.getLastName());
        assertEquals("0987654321", updatedContact.getPhone());
        assertEquals("456 Elm St", updatedContact.getAddress());
    }

    // Test Updating Partial Fields of a Contact
    @Test
    public void testUpdatePartialFields() {
        ContactService service = new ContactService();
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(contact);

        service.updateContact("12345", null, "Smith", null, "456 Elm St");

        Contact updatedContact = service.getContacts().get(0); // Retrieve the updated contact
        assertEquals("John", updatedContact.getFirstName()); // First name unchanged
        assertEquals("Smith", updatedContact.getLastName()); // Last name updated
        assertEquals("1234567890", updatedContact.getPhone()); // Phone unchanged
        assertEquals("456 Elm St", updatedContact.getAddress()); // Address updated
    }

    // Test Updating a Non-Existent Contact
    @Test
    public void testUpdateNonexistentContact() {
        ContactService service = new ContactService();

        // Updating a non-existent contact should throw an exception
        assertThrows(IllegalArgumentException.class, () ->
            service.updateContact("12345", "Jane", "Smith", "0987654321", "456 Elm St"));
    }

    // Test Deleting Multiple Contacts
    @Test
    public void testDeleteMultipleContacts() {
        ContactService service = new ContactService();
        Contact contact1 = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        Contact contact2 = new Contact("67890", "Jane", "Smith", "0987654321", "456 Elm St");

        service.addContact(contact1);
        service.addContact(contact2);

        service.deleteContact("12345");
        assertEquals(1, service.getContacts().size()); // Only one contact should remain
        assertEquals(contact2, service.getContacts().get(0)); // Remaining contact is contact2

        service.deleteContact("67890");
        assertEquals(0, service.getContacts().size()); // No contacts should remain
    }

    // Test Edge Case: Empty Contact List
    @Test
    public void testEmptyContactList() {
        ContactService service = new ContactService();

        assertEquals(0, service.getContacts().size()); // Ensure the list starts empty
    }
    
    @Test
    public void testAddContactInvalidContactId() {
        ContactService service = new ContactService();

        // Attempting to add a contact with a null ID should throw an exception
        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(new Contact(null, "John", "Doe", "1234567890", "123 Main St"));
        });
    }

    @Test
    public void testDeleteContactFromEmptyList() {
        ContactService service = new ContactService();

        // Attempting to delete from an empty list should throw an exception
        assertThrows(IllegalArgumentException.class, () -> service.deleteContact("12345"));
    }

    @Test
    public void testUpdateContactNoChanges() {
        ContactService service = new ContactService();
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(contact);

        // Attempting to update with no changes should not alter the contact
        service.updateContact("12345", null, null, null, null);

        Contact updatedContact = service.getContacts().get(0);
        assertEquals("John", updatedContact.getFirstName());
        assertEquals("Doe", updatedContact.getLastName());
        assertEquals("1234567890", updatedContact.getPhone());
        assertEquals("123 Main St", updatedContact.getAddress());
    }

    @Test
    public void testAddAndDeleteMultipleContacts() {
        ContactService service = new ContactService();
        Contact contact1 = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        Contact contact2 = new Contact("67890", "Jane", "Smith", "0987654321", "456 Elm St");

        service.addContact(contact1);
        service.addContact(contact2);

        assertEquals(2, service.getContacts().size()); // Check if both contacts were added

        // Delete first contact
        service.deleteContact("12345");
        assertEquals(1, service.getContacts().size());
        assertEquals(contact2, service.getContacts().get(0)); // Verify remaining contact

        // Delete second contact
        service.deleteContact("67890");
        assertEquals(0, service.getContacts().size()); // Verify no contacts remain
    }

    @Test
    public void testUpdateNonExistentContact() {
        ContactService service = new ContactService();

        // Updating a non-existent contact should throw an exception
        assertThrows(IllegalArgumentException.class, () ->
            service.updateContact("12345", "Jane", "Smith", "0987654321", "456 Elm St"));
    }

    @Test
    public void testDeleteNonExistentContact() {
        ContactService service = new ContactService();

        // Attempting to delete a non-existent contact should throw an exception
        assertThrows(IllegalArgumentException.class, () -> service.deleteContact("12345"));
    }

    
}
